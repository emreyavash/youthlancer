from django.contrib import admin
from .models import İsBilgileri
# Register your models here.

admin.site.register(İsBilgileri)