from django.contrib import admin
from .models import Kategori,AltKategori
# Register your models here.

admin.site.register(Kategori)
admin.site.register(AltKategori)