
from unicodedata import name
from django.urls import path
urlpatterns = [
]
